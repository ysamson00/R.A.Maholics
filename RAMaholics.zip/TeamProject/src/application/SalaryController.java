package application;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class SalaryController {

	@FXML
	private TextField ID;

	@FXML
	private Button submitButton;


	@FXML
	private ListView<String> list;

	@FXML
	private TextArea totalSalary;

	@FXML
	private DatePicker from;

	@FXML
	private DatePicker to;


	ArrayList<Employee> employ = new ArrayList<Employee>();
	Model mod = new Model();

	@FXML
	void HandleSubmitButton(ActionEvent event) throws IOException, ParseException{
		list.getItems().clear();
		list.getItems().add("Hourly Wages:" + "\t\t\t" + " $7.25");
		Alert alert = new Alert(AlertType.NONE);
		double total=0;
		int employeeID = Integer.parseInt(ID.getText());
		String startDate = from.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		String endDate = to.getValue().format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		mod.ReadEmployeeFile(employ);
		if(!mod.CheckEmployeeID(employ, employeeID)){
			alert.setAlertType(AlertType.ERROR);
			alert.setTitle("Error");
			alert.setContentText("Employee ID not found");
			alert.show();
		}else{
			mod.CalculateEmployeeSalary(employeeID, startDate, endDate);
		}
		File fp = new File("employeesalary.txt");
		Scanner scan = new Scanner(fp);
		while(scan.hasNextLine()){
			String nextLine = scan.nextLine();
			String values[] = nextLine.split(" ");
			list.getItems().add(nextLine);
			total += Double.parseDouble(values[1]);

		}//end while
		totalSalary.setText(Double.toString(total));

		PrintWriter pw = new PrintWriter(fp);
		pw.close();

	}


	@FXML
	void HandleHomeButton(ActionEvent event) throws IOException{
		mod.ClearEmployeeLoginSession();
		Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

}
