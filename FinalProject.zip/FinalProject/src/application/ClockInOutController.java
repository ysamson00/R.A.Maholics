package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ClockInOutController {

	@FXML
	private TextField employID;

	//variables
	Model mod = new Model();
	ArrayList<Employee> employ = new ArrayList<Employee>();


	@FXML
	void HandleClockInButton(ActionEvent event){
		try {
			mod.ReadEmployeeFile(employ);

			Alert alert = new Alert(AlertType.NONE);
			int pass = Integer.parseInt(employID.getText());
			Boolean isValid = mod.CheckEmployeeID(employ, pass);
			if(isValid == true){
				RecordClock("login");
				LoadMainScreen(event);
			} else {
				alert.setAlertType(AlertType.ERROR);
				alert.setHeaderText(null);
				alert.setTitle("Error!");
				alert.setContentText("Passcode does not exist");
				alert.show();
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}//end handle

	@FXML
	void HandleClockOutButton(ActionEvent event){
		try {
			mod.ReadEmployeeFile(employ);

			Alert alert = new Alert(AlertType.NONE);
			int pass = Integer.parseInt(employID.getText());
			Boolean isValid = mod.CheckEmployeeID(employ, pass);
			if(isValid == true){
				RecordClock("logout");
				LoadMainScreen(event);
			} else {
				alert.setAlertType(AlertType.ERROR);
				alert.setHeaderText(null);
				alert.setTitle("Error!");
				alert.setContentText("Passcode does not exist");
				alert.show();
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}//end handle


	public void LoadMainScreen(ActionEvent event) throws IOException{
		Pane pane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(pane);
		Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}

	public void RecordClock(String s) throws IOException{
		File fp = new File("employeeclock.txt");
		FileWriter writer = new FileWriter(fp, true);
		SimpleDateFormat dtf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date currentDate = Calendar.getInstance().getTime();
		String currentDateTime = dtf.format(currentDate);
		String loginID = employID.getText() + " " + currentDateTime + " " + s + "\n";
		writer.write(loginID);
		writer.close();
	}

}
