package application;
//RAMaholics , Dinh Tran , Brandon Greene , Phetty Samson , Victor Aguilar
public class Employee {

	public String name, dateOfBirth, gender , phoneNumber;
	public int userID;

	public Employee(String name, int userID){
		this.name = name;
		this.userID = userID;
	}

	public String GetName(){
		return this.name;
	}

	public String GetDateOfBirth(){
		return this.dateOfBirth;
	}

	public String GetGender(){
		return this.gender;
	}

	public int GetUserID(){
		return this.userID;
	}

	public String GetPhoneNumber(){
		return this.phoneNumber;
	}

	public void SetName(String name){
		this.name = name;
	}

	public void SetUserID(int userID){
		this.userID = userID;
	}

	public void SetDateOfBirth(String dateOfBirth){
		this.dateOfBirth = dateOfBirth;
	}

	public void SetPhoneNumber(String phoneNum){
		this.phoneNumber = phoneNum;
	}

	public void SetGender(String gen){
		this.gender = gen;
	}

}
