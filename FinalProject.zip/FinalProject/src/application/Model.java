package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Model {

	public void ReadEmployeeFile(ArrayList<Employee> employ) throws IOException{
		File fp = new File("employee.txt");
		Scanner scan = new Scanner(fp);
		while(scan.hasNextLine()){
			String line = scan.nextLine();
			String [] values = line.split(" ");
			Employee newEm = new Employee(values[0], Integer.parseInt(values[1]));
			newEm.SetGender(values[2]);
			newEm.SetDateOfBirth(values[3]);
			newEm.SetPhoneNumber(values[4]);
			employ.add(newEm);
		}
		scan.close();
	}

	public Boolean CheckEmployeeID(ArrayList<Employee> employ, int employeeID){
		Boolean isValid = true;
		for (int i = 0; i < employ.size(); i++){
			//System.out.println(employ.get(i).GetUserID());
			if(employeeID == employ.get(i).GetUserID()){
				isValid = true;
				break;
			}else{
				isValid = false;
			}
		}
		return isValid;
	}

	public void CalculateEmployeeSalary(int employeeID, String startDate, String endDate) throws ParseException, IOException{
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		EmployeeDailySalary em = new EmployeeDailySalary();
		em.SetEmployeeID(employeeID);
		Date start = dateFormat.parse(startDate);
		Date end = dateFormat.parse(endDate);
		File fp = new File("employeeclock.txt");
		Scanner scan = new Scanner(fp);
		while(scan.hasNextLine()){
			String newLine = scan.nextLine();
			String values[] = newLine.split(" ");
			Date currentDate = dateFormat.parse(values[1]);
			if(currentDate.compareTo(start)>=0 && currentDate.compareTo(end)<=0 ){
				if(values[3].equalsIgnoreCase("login") && (Integer.parseInt(values[0]) == em.GetEmployeeID())){
					em.SetDate(values[1]);
					em.SetClockInTime(values[2]);
				}

				if(values[3].equalsIgnoreCase("logout") && (Integer.parseInt(values[0]) == em.GetEmployeeID())){
					em.SetClockOutTime(values[2]);
					Date clockIn = timeFormat.parse(em.clockInTime);
					Date clockOut = timeFormat.parse(em.clockOutTime);
					long difference = (clockOut.getTime() - clockIn.getTime())/ (60*60*1000) % 24;
					em.SetSalary(difference*7.25);
					String employ = "\n" + em.GetDate() + " " + em.GetSalary();
					FileWriter write = new FileWriter("employeesalary.txt", true);
					write.write(employ);
					write.close();
				}
			}//end if
		}//end while

		scan.close();


	}//end calculate


	public void ClearEmployeeLoginSession(){
		PrintWriter writeNew = null;
		try{
			writeNew = new PrintWriter("employeeloginsession.txt");
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		writeNew.close();
	}

}//end class
