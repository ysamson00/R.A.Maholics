1. R.A.M (Restaurant Activites Manager) 

2. (R.A.M~aholics)
 	
3.	-Dinh Tran
   	-Brandon Greene
  	-Phetty Samson
	-Victor Aguilar

4. A tool for restaurant operations such as order taking, table scheduling, salaries, revenue, and employee clocking (in/out) timestamps.

5. Known bugs include:
	1- Sometimes error exception will be thrown when pulling new employee salary.
6. Pass code : 7777 (any employee ID, that can be found (in employee.txt) or created later)
7. Java 1.8 compiler